<html>
<head>
    <title>贫困户</title>
    <meta charset="UTF-8">
 <meta name="description" content="贫困户" />   
<meta name="keywords" content="贫困户,没钱,贫穷,taofan，给点钱，穷啦，穷逼"> 

<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0, user-scalable=no">
<meta name="description" content="讨饭网" />
<link rel="icon" href="/favicon.ico" sizes="32x32" />
<link rel="icon" href="/favicon.ico" sizes="192x192" />
<link rel="apple-touch-icon" href="/favicon.ico" />
<meta name="msapplication-TileImage" content="/favicon.ico" />
<meta http-equiv="Cache-Control" content="no-siteapp" />

 <script src="https://lf6-cdn-tos.bytecdntp.com/cdn/expire-1-y/mdui/0.4.2/js/mdui.min.js" type="application/javascript"></script>
   <link href="https://lf6-cdn-tos.bytecdntp.com/cdn/expire-1-y/mdui/0.4.2/css/mdui.min.css" type="text/css" rel="stylesheet">
    
<link rel="stylesheet" href="https://cdn.bootcss.com/twitter-bootstrap/4.0.0/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  <link rel="stylesheet" href="/taofan.css">
  <script src="https://www.recaptcha.net/recaptcha/api.js?render=6LfrusgZAAAAAK0G4PR0FDdn4mpSgjeVP79Q99ax"></script> 
<script src="https://old.xiu.no/plugin/fox_alipay/oddfox/static/js/fox_paycheck.js"></script>

<link rel="stylesheet" href="./66/css/bootstrap.min.css">
    <link rel="stylesheet" href="./66/css/style.css">
    <style>
        /* customizable snowflake styling */
        .snowflake {
            color: #fff;
            font-size: 1em;
            font-family: Arial, sans-serif;
            text-shadow: 0 0 5px #000;
        }
        .grecaptcha-badge {
            visibility: hidden !important;
        }
@-webkit-keyframes snowflakes-fall {
            0% {
                top:-10%
            }
            100% {
                top:100%
            }
        }
@-webkit-keyframes snowflakes-shake {
            0%, 100% {
                -webkit-transform:translateX(0);
                transform:translateX(0)
            }
            50% {
                -webkit-transform:translateX(80px);
                transform:translateX(80px)
            }
        }
@keyframes snowflakes-fall {
            0% {
                top:-10%
            }
            100% {
                top:100%
            }
        }
@keyframes snowflakes-shake {
            0%, 100% {
                transform:translateX(0)
            }
            50% {
                transform:translateX(80px)
            }
        }
        .snowflake {
            position:fixed;
            top:-10%;
            z-index:9999;
            -webkit-user-select:none;
            -moz-user-select:none;
            -ms-user-select:none;
            user-select:none;
            cursor:default;
            -webkit-animation-name:snowflakes-fall, snowflakes-shake;
            -webkit-animation-duration:10s, 3s;
            -webkit-animation-timing-function:linear, ease-in-out;
            -webkit-animation-iteration-count:infinite, infinite;
            -webkit-animation-play-state:running, running;
            animation-name:snowflakes-fall, snowflakes-shake;
            animation-duration:10s, 3s;
            animation-timing-function:linear, ease-in-out;
            animation-iteration-count:infinite, infinite;
            animation-play-state:running, running
        }
        .snowflake:nth-of-type(0) {
            left:1%;
            -webkit-animation-delay:0s, 0s;
            animation-delay:0s, 0s
        }
        .snowflake:nth-of-type(1) {
            left:10%;
            -webkit-animation-delay:1s, 1s;
            animation-delay:1s, 1s
        }
        .snowflake:nth-of-type(2) {
            left:20%;
            -webkit-animation-delay:6s, .5s;
            animation-delay:6s, .5s
        }
        .snowflake:nth-of-type(3) {
            left:30%;
            -webkit-animation-delay:4s, 2s;
            animation-delay:4s, 2s
        }
        .snowflake:nth-of-type(4) {
            left:40%;
            -webkit-animation-delay:2s, 2s;
            animation-delay:2s, 2s
        }
        .snowflake:nth-of-type(5) {
            left:50%;
            -webkit-animation-delay:8s, 3s;
            animation-delay:8s, 3s
        }
        .snowflake:nth-of-type(6) {
            left:60%;
            -webkit-animation-delay:6s, 2s;
            animation-delay:6s, 2s
        }
        .snowflake:nth-of-type(7) {
            left:70%;
            -webkit-animation-delay:2.5s, 1s;
            animation-delay:2.5s, 1s
        }
        .snowflake:nth-of-type(8) {
            left:80%;
            -webkit-animation-delay:1s, 0s;
            animation-delay:1s, 0s
        }
        .snowflake:nth-of-type(9) {
            left:90%;
            -webkit-animation-delay:3s, 1.5s;
            animation-delay:3s, 1.5s
        }
        .snowflake:nth-of-type(10) {
            left:25%;
            -webkit-animation-delay:2s, 0s;
            animation-delay:2s, 0s
        }
        .snowflake:nth-of-type(11) {
            left:65%;
            -webkit-animation-delay:4s, 2.5s;
            animation-delay:4s, 2.5s
        }
    </style>
</head>
    <div class="snowflakes" aria-hidden="true">
        <div class="snowflake">
            2020
        </div>
        <div class="snowflake">
            变有钱
        </div>
        <div class="snowflake">
            暴富
        </div>
        <div class="snowflake">
            努力
        </div>
        <div class="snowflake">
            奋斗
        </div>
        <div class="snowflake">
            💸
        </div>
        <div class="snowflake">
            ¥
        </div>
        <div class="snowflake">
            $
        </div>
        <div class="snowflake">
            ¥
        </div>
        <div class="snowflake">
            $
        </div>
        <div class="snowflake">
            ¥
        </div>
        <div class="snowflake">
            $
        </div>
        <div class="snowflake">
            ¥
        </div>
        <div class="snowflake">
            $
        </div>
        <div class="snowflake">
            ¥
        </div>
        <div class="snowflake">
            $
        </div>
        <div class="snowflake">
            ¥
        </div>
        <div class="snowflake">
            $
        </div>
        <div class="snowflake">
            ❅
        </div>
        <div class="snowflake">
            ❆
        </div>
        <div class="snowflake">
            ❅
        </div>
        <div class="snowflake">
            ❆
        </div>
        <div class="snowflake">
            ❅
        </div>
        <div class="snowflake">
            ❆
        </div>
        <div class="snowflake">
            ❅
        </div>
        <div class="snowflake">
            ❆
        </div>
        <div class="snowflake">
            ❅
        </div>
        <div class="snowflake">
            ❆
        </div>
        <div class="snowflake">
            ❅
        </div>
        <div class="snowflake">
            ❆
        </div>
        <div class="snowflake">
            ❅
        </div>
        <div class="snowflake">
            ❆
        </div>
        <div class="snowflake">
            ❅
        </div>
        <div class="snowflake">
            ❆
        </div>
    </div>
    <div style='Height:20px'></div>
    <body class="mdui-theme-primary-blue mdui-theme-accent-blue">
        <div class="mdui-container" style="max-width: 500px;">
            <div class="mdui-card" style="border-radius: 16px;">
                <div class="mdui-card-menu">
                    <button onclick="window.location.href='/'" class="mdui-btn mdui-btn-icon mdui-text-color-grey"><i class="mdui-icon material-icons">home</i>
                    </button>
                </div>
                <div class="mdui-card-primary">
                    <div class="mdui-card-primary-title">
                        贫困户
                    </div>
                    <div class="mdui-card-primary-subtitle">
                        Pinkun.Hu
                    </div>
                </div>
                <div class="mdui-card-content">
                    贫穷限制了我的想象力，创造力，巧克力。<br/>
                    Poverty limits my imagination, my creativity, my chocolate.<br/>
                    希望您帮我摆脱贫穷。<br/>
                    I hope you can help me out of poverty.</h2>
                    <!-- 加载 -->
                    <div id='loading' style="position: absolute;margin: auto;top: 0;left: 0;right: 0;bottom: 0;display: none;width: 50px;height: 50px" class="mdui-spinner mdui-spinner-colorful"></div>
                    
 <div class="card-details">
            
            <div class="row">
                
              <div class="form-group col-sm-8" id="amountchose">
                <label for="card-holder">扶贫金额</label>
                
                
                
                
                
                
                
                   
                
                
      <input type="text" class="form-control" value="1.68" id="money" required="" onchange="checkvalue();">            
                
                
                
                
                
                
                
                
                
                
                
                
                
                
               


   
   
   
   
   
   
   
   
   
   
            
                
                
           
                
                
           
                  
                  
              </div>
              <div class="form-group col-sm-12" id="amountinput" style="display: none;">
                <label for="card-holder">扶贫金额(人民币 ¥)</label>
                
                <input type="text" class="form-control" value="1.68" id="money" required="" onchange="checkvalue();">
                <script>function Num()
{
	document.getElementById("money").value=Math.floor(Math.random()*5+5) + Math.ceil(Math.random()*10)/10
}
</script>

              </div>
              <div class="form-group col-sm-4" id="inputtip">
                <label for="card-number">&nbsp;&nbsp;</label>
                <input type="button" class="btn btn-primary btn-block" value="随缘一下" onclick="Num()">
              </div>
              
<script>
var text=["好好学习","加油","努力赚钱","不要被消灭！","努力活下去","成为最贫穷的人！"]
function infotext(){
var num=randomNum(1,text.length);
var texts='';
for(var i=0;i<num.length;i++){
texts+=text[num[i]]+"";
}
document.getElementById("comment").value=texts;
}
//生成ranNum个0到arrLength-1不重复的随机数
function randomNum(ranNum,arrLength){
if(ranNum>arrLength){alert("您生成的个数不能大于数组长度！请重新设置参数！");return;}
var num=new Array()
for(var i=0;i<ranNum;i++){
var ran=Math.floor(Math.random() * arrLength);
if(num.indexOf(ran)<0){num[i] =ran;}
else{i--;}
}
return num;
} 
</script>             
              
              <div class="form-group col-sm-8">
                <label for="card-number">扶贫留言</label>
     
                <input type="text" class="form-control" id="comment" value="请输入你的留言内容"  onclick="text()">
               
              </div>

              <div class="form-group col-sm-4">
                <label for="card-number">&nbsp;&nbsp;</label>
                <input type="button" class="btn btn-primary btn-block" value="随机留言" onclick="infotext()">
              </div>
              <div class="form-group col-sm-12">
                <button type="button" class="btn btn-primary btn-block" onclick="go()">立马扶贫</button>
              </div>
            </div>
          </div>                  
                    
                   
                        
                     
                </div>
                <div class="mdui-card-actions">
                   
                </div>
            </div>
        </div>
        <div style='Height:20px'></div>
        <div class="mdui-container" style="max-width: 500px;">
            <div class="mdui-card" style="border-radius: 16px;">
                <div class="mdui-card-menu">
                </div>
                <div class="mdui-card-primary">
                    <div class="mdui-card-primary-title">
                        扶贫记录 | >=1元的最近5笔
                    </div>
                    <div class="mdui-card-primary-subtitle">
                        Help Record
                    </div>
                </div>
                <div class="mdui-card-content">
                    <ul class="mdui-list">
                        <?php
                        require_once 'config.php';
                        $arr = mysqli_query($conn,"SELECT * FROM `order` ORDER BY `time` DESC");
                        $j = 0;
                        while ($row = mysqli_fetch_object($arr)) {
                            if ((int)$row->money < 1) {
                                continue;
                            }
                            $time = date('Y-m-d H:i:s',$row->time);
                            $comment = htmlspecialchars($row->comment);
                            echo "  <li class=\"mdui-list-item mdui-ripple\">
                                            <div class=\"mdui-list-item-content\">
                                              <div class=\"mdui-list-item-title\">$comment</div>
                                              <div class=\"mdui-list-item-text mdui-list-item-one-line\">$row->money 元 | $time</div>
                                            </div>
                                          </li>";
                            $j++;
                            if ($j >= 5) {
                                break;
                            }
                        }
                        ?>
                    </div>
                </ul>
            </div>
        </div>
    </div>
    <div style='Height:20px'></div>
</div>
<?php
$numx = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM `config` WHERE `type`='num'"))['content'];
$moneyx = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM `config` WHERE `type`='money'"))['content'];
?>
<div class="mdui-container" style="max-width: 500px;">
    <div class="mdui-card" style="border-radius: 16px;">
        <div class="mdui-card-menu"></div>
        <div class="mdui-card-primary">
            <div class="mdui-card-primary-title">
                扶贫统计 | 您的支持,我们皆有记录
            </div>
            <div class="mdui-card-primary-subtitle">
                Help conclusion
            </div>
        </div>
        <div class="mdui-card-content">
            <li class="mdui-list-item mdui-ripple"> <i class="mdui-list-item-icon mdui-icon material-icons">move_to_inbox</i>

                <div class="mdui-list-item-content">
                    <?php echo $numx ?>个
                </div>
            </li>
            <li class="mdui-list-item mdui-ripple"> <i class="mdui-list-item-icon mdui-icon material-icons">move_to_inbox</i>

                <div class="mdui-list-item-content">
                    <?php echo $moneyx ?>元
                </div>
            </li>
        </div>
    </div>
</div>
 <div style='Height:20px'></div>
 <div class="mdui-container" style="max-width: 500px;">
    <div class="mdui-card" style="border-radius: 16px;">
        <div class="mdui-card-content">
        <center>Copyright © 2020 - <?php echo date('Y') ?> <a style='color:black' href=''>贫困户源码下载</a> All Rights Reserved.</center>
        </div>
    </div>
</div>
 <div style='Height:20px'></div>
</body>
<script src="https://cdn.staticfile.org/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdn.bootcss.com/twitter-bootstrap/4.0.0/js/bootstrap.min.js"></script>
<!--<script type="text/javascript" src="https://cdn.jsdelivr.net/gh/yumusb/cdn@master/push.js"></script>-->
<!--<script src="https://commerce.coinbase.com/v1/checkout.js?version=201807"> </script>-->
<!--<script type="text/javascript" src="https://cdn.jsdelivr.net/gh/yumusb/cdn@master/js/snow.js"></script>-->
<script>
var $ = mdui.JQ;

function go() {
    var x = mdui.snackbar({
        message: '处理中',
        position: 'right-top'
    });
    $.ajax({
        method: 'POST',
        url: './api.php',
        timeout: 10000,
        data: {
            'money': $('#money').val(),
            'comment': $('#comment').val()
        },
        success: function(data) {
            x.close();
            data = eval('(' + data + ')');
            if (data[0] == '200') {
                    mdui.snackbar({
                        message: '处理成功,跳转中...',
                        position: 'right-top'
                    });
                window.location.href = 'pay.php';
            } else {
                mdui.snackbar({
                    message: data[1],
                    position: 'right-top'
                });
            }
        },
        complete: function(xhr, status) {
            if (status == 'timeout') {
                x.close();
                mdui.snackbar({
                    message: '请求超时',
                    position: 'right-top'
                });
            }
        }
    });
}
</script>
